﻿using EMP_WebApi.Models;
using System.Collections.Generic;

namespace EMP_WebApi.Repository
{
    public interface IEmployee
    {
        IEnumerable<EmployeeModel> GetAllEmployees();
        EmployeeModel GetEmployee(long id);
        void DeleteEmployee(EmployeeModel employee);
        void AddEmployee(EmployeeModel employee);
        void UpdateEmployee(EmployeeModel employeeModel, EmployeeModel employee);
    }
}
