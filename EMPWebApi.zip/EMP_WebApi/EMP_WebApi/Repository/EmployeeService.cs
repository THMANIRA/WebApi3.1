﻿using EMP_WebApi.Data;
using EMP_WebApi.Models;
using System.Collections.Generic;
using System.Linq;

namespace EMP_WebApi.Repository
{
    public class EmployeeService:IEmployee
    {
       private readonly EmployeeDbContext _employeeContext;
        public EmployeeService(EmployeeDbContext context)
        {
            _employeeContext = context;
        }
        public IEnumerable<EmployeeModel> GetAllEmployees()

        {
         var employee =   _employeeContext.EmployeesTable1.ToList();
                      return (employee);
        }
        public EmployeeModel GetEmployee(long id)
        {
            //return _employeeContext.EmployeesTable1
            //    .FirstOrDefault(e => e.EmployeeId == id);
            return _employeeContext.EmployeesTable1.Find(id);

        }
        public void DeleteEmployee(EmployeeModel employee)
        {
            _employeeContext.EmployeesTable1.Remove(employee);
            _employeeContext.SaveChanges();
        }
        public void UpdateEmployee(EmployeeModel employeeModel, EmployeeModel employee)
        {
            employeeModel.FirstName = employee.FirstName;
            employeeModel.LastName = employee.LastName;
            employeeModel.Email = employee.Email;
            employeeModel.PhoneNumber = employee.PhoneNumber;
            _employeeContext.SaveChanges();
        }
        public void AddEmployee(EmployeeModel employee)
        {
            _employeeContext.EmployeesTable1.Add(employee);
            _employeeContext.SaveChanges();
        }
    }
}
